<footer>

    <div class="footer__copyright">
        <small>Copyright &copy; 2023 | Team Prefetch | All rights reserved</small>
    </div>
</footer>


<script src="<?= ROOT_URL ?>./js/main.js"></script>

<!-- Data Table Link -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.js"></script>
<script>
    jQuery(document).ready(function($) {
        $('#table').DataTable();
    });
</script>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>


</body>

</html>