<?php
include 'partials/header.php';
?>




<!-- <section class="category__buttons">
    <div class="container category__buttons-container">
        <a href="" class="category__button">Art</a>
        <a href="" class="category__button">Wild Life</a>
        <a href="" class="category__button">Travel</a>
        <a href="" class="category__button">Science & Technology</a>
        <a href="" class="category__button">Food</a>
        <a href="" class="category__button">Music</a>
    </div>
</section> -->
<!-- ============= END OF CATEGORY BUTTONS ============= -->

<?php
include 'partials/footer.php';
?>