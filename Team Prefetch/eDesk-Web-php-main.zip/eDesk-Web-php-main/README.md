# eDesk-Web-php
 This is a Complete Web App Project using php for Complete Online Complain, Suggestion, Request and many more feature for any organization transparency System.
